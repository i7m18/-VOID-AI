package com.voidai.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF090910)
private val Panel = Color(0xFF171521)
private val Purple = Color(0xFF9D75FF)
private val Foreground = Color(0xFFF5F1FF)
private val Muted = Color(0xFFAAA4BE)
private data class Message(val id: Long, val text: String, val user: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VoidScreen() }
    }
}

@Composable
private fun VoidScreen() {
    var input by remember { mutableStateOf("") }
    var info by remember { mutableStateOf(false) }
    val messages = remember { mutableStateListOf(
        Message(1, "أهلًا بيك في VOID AI 👋", false),
        Message(2, "هاي النسخة الحالية واجهة أولية. الردود محلية وتجريبية، وماكو اتصال بنموذج ذكاء اصطناعي حقيقي بعد.", false)
    ) }
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = darkColorScheme(primary=Purple, background=Bg, surface=Panel, onBackground=Foreground, onSurface=Foreground)) {
            Scaffold(
                containerColor=Bg,
                topBar={
                    Row(Modifier.fillMaxWidth().background(Panel).padding(16.dp), verticalAlignment=Alignment.CenterVertically) {
                        Box(Modifier.size(44.dp).background(Purple.copy(alpha=.2f), CircleShape), contentAlignment=Alignment.Center) {
                            Icon(Icons.Default.Bolt, null, tint=Purple, modifier=Modifier.size(28.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("VOID AI", color=Foreground, fontSize=21.sp, fontWeight=FontWeight.ExtraBold)
                            Text("مساعدك الذكي • إصدار أولي", color=Muted, fontSize=12.sp)
                        }
                        IconButton(onClick={info=!info}) { Icon(Icons.Default.Tune, "حالة الميزات", tint=Muted) }
                    }
                },
                bottomBar={
                    Row(Modifier.fillMaxWidth().background(Panel).padding(10.dp), verticalAlignment=Alignment.CenterVertically) {
                        OutlinedTextField(value=input, onValueChange={input=it}, modifier=Modifier.weight(1f), placeholder={Text("اكتب رسالتك هنا...")}, maxLines=4, shape=RoundedCornerShape(20.dp))
                        Spacer(Modifier.width(8.dp))
                        IconButton(onClick={
                            val text=input.trim()
                            if(text.isNotEmpty()) {
                                messages.add(Message(System.nanoTime(), text, true))
                                messages.add(Message(System.nanoTime()+1, "استلمت رسالتك. هاي نسخة تجريبية وما مرتبطة بخدمة AI حالياً.", false))
                                input=""
                            }
                        }, modifier=Modifier.size(48.dp).background(Purple,CircleShape)) { Icon(Icons.Default.Send, "إرسال", tint=Color.White) }
                    }
                }
            ) { padding ->
                Column(Modifier.fillMaxSize().padding(padding).padding(horizontal=14.dp)) {
                    if(info) {
                        Surface(color=Panel, shape=RoundedCornerShape(14.dp), modifier=Modifier.fillMaxWidth().padding(top=12.dp)) {
                            Column(Modifier.padding(14.dp)) {
                                Text("حالة المشروع", fontWeight=FontWeight.Bold)
                                Text("المحادثة: محلية تجريبية", color=Muted)
                                Text("AI أونلاين: غير مربوط", color=Muted)
                                Text("AI أوفلاين: غير مضاف", color=Muted)
                                Text("الصوت والتحكم بالجهاز: غير مفعّلين", color=Muted)
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(vertical=12.dp), verticalAlignment=Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("مساحة المحادثة", color=Foreground, fontWeight=FontWeight.Bold, fontSize=17.sp)
                            Text("نسخة تطوير أولية", color=Muted, fontSize=12.sp)
                        }
                        FilledTonalIconButton(onClick={messages.clear();messages.add(Message(System.nanoTime(),"بدأنا محادثة جديدة. شنو تحب تسأل؟",false))}) { Icon(Icons.Default.Add,"محادثة جديدة") }
                    }
                    LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding=PaddingValues(vertical=8.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
                        items(messages, key={it.id}) { msg ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement=if(msg.user) Arrangement.Start else Arrangement.End) {
                                Surface(color=if(msg.user) Purple.copy(alpha=.25f) else Panel, shape=RoundedCornerShape(18.dp), modifier=Modifier.widthIn(max=310.dp)) {
                                    Text(msg.text, Modifier.padding(14.dp), color=Foreground, lineHeight=22.sp)
                                }
                            }
                        }
                    }
                    Text("تنبيه: هذه الواجهة لا تولّد إجابات بواسطة نموذج AI بعد.", color=Muted, fontSize=11.sp, modifier=Modifier.padding(bottom=8.dp))
                }
            }
        }
    }
}
